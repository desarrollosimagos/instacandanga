<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h5><a href="/home">inicio</a> / twitter</h5>
                </div>

                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-12 col-md-12">
                            <a href="/auth/twitter" class="btn btn-primary" role="button">
                                <i class="fa fa-plus" aria-hidden="true"></i> Agregar cuenta
                            </a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12 col-md-12">
                            <br>
                        </div>
                    </div>
                    <div class="row">

                        <?php $__currentLoopData = $twitter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lnk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-3 col-md-3">
                                <div class="thumbnail">
                                    <img src="<?php echo e($lnk->avatar); ?>" alt="...">
                                    <div class="caption">
                                        <h3><?php echo e($lnk->handle); ?></h3>
                                        <p><a href="#" class="btn btn-primary" role="button">Eliminar</a> 
                                        <a href="#" class="btn btn-default" role="button">Publicar</a></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>