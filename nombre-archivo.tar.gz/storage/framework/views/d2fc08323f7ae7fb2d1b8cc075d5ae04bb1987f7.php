<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Panel de Validación de cuenta</div>
                <div class="panel-body">
                    <?php if(session('status')): ?>
						<div class="alert alert-success">
							<?php echo e(session('status')); ?>

						</div>
					<?php endif; ?>
					<?php if(session('warning')): ?>
						<div class="alert alert-warning">
							<?php echo e(session('warning')); ?>

						</div>
					<?php endif; ?>

                    <form class="form-horizontal" role="form">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('code') ? ' has-error' : ''); ?>">
                            <label for="code" class="col-md-4 control-label">Codigo de Verificacion</label>

                            <div class="col-md-6">
                                <input id="code" type="code" class="form-control" name="code" value="<?php echo e(old('code')); ?>" required>

                                <?php if($errors->has('code')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('code')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="button" id="enviar" class="btn btn-primary">
                                    Enviar
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	$( "#enviar" ).click(function() {
		window.location = "/user/activation/"+ document.getElementById('code').value;
	});
	/*function enviar(){
		window.location = "/user/activation/"+ document.getElementById('code').value;
	}*/
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>